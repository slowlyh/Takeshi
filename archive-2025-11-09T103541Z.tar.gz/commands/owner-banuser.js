let handler = async (m, { conn, text }) => {
	if (!text) throw "Who wants to be banned?";
	let who;
	if (m.isGroup) who = m.mentionedJid[0];
	else who = m.chat;
	if (!who) throw "Tag??";
	let users = (global.db.data.users[who].banned = true);
	m.reply("Success!");
};
handler.help = ["ban"];
handler.tags = ["owner"];
handler.command = /^ban(user)?$/i;
handler.owner = true;

export default handler;
